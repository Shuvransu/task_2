# -*- coding: utf-8 -*-
"""
**************************************************************************
*                  IMAGE PROCESSING (Prashikshan 2017)
*                  ================================
*  This software is intended to teach image processing concepts
*
*  MODULE: Task2C
*  Filename: getCellVal.py
*  Version: 1.0.0  
*  Date: May 3, 2017
*  
*  Author: Prashikshan Team.
**************************************************************************
"""
# detectCellVal detects the numbers/operatorsm,
# perform respective expression evaluation
# and stores them into the grid_map 
# detectCellVal(img,grid_map)

# Find the number/operators, perform the calculations and store the result into the grid_map
# Return the resultant grid_map
import cv2
import numpy as np
# comment here
def detectCellVal(img_rgb,grid_map):
	#your code here
        ###################### read image ##############################
        grid_line_x= 7;
        grid_line_y= 7;
        m=600/(grid_line_x-1);
        n=600/(grid_line_y-1);
        np.zeros((6,6));

        ####################### digits #################################
        digits= [] 
        for l in range(0,12):
          t_l= cv2.imread(str(l)+'.jpg',0);
          digits.append(t_l);
        ####################### main body #############################
        for i in range(1,5):
          list_i=list();
         for j in range(1,6):
           copy= img_rgb[100*(j-1) : 100*j , 100*(i-1) : 100*i];
           for k in range(len(digits)):
             diff= cv2.matchTemplate(copy, digits[k], cv2.TM_CCOEFF_NORMED);
             dim_k= cv2.minMaxLoc(diff)
             result= np.any(diff)
             if result is True:
               list_i.append(k);
               break;
             else:
               list_i.append(0);
        ########################## print ##############################
        res= list_1+list_2+list_3+list_4+list_5
        for m in range(len(res))
          cv2.putText(img_rgb, str(res[i]), (50*m, 550), cv2.FONT_HERSEY_PLAIN, 5, (0,0,255),4)
  
  
        cv2.waitKey(0)
        cv2.destroyAllWindows()
